const BlogPost = require('../models/post');
const express = require('express');



const createPost = async (req, res) => {
    try {
        const {title, content, categories, tags} = req.body;
        const {userId} = req;
        console.log(`userID: ${userId}`);

        const blogPost = new BlogPost({
            title,
            content,
            author: userId,
            categories,
            tags
        })

        const result = await blogPost.save()

        res.status(201).json({
            message: "Created Post Successfully",
            result
        })

    } catch (error) {
        return res.status(500).json({
            message: "Internal Server Error",
            error
        })
    }
}

const getAllPost = async (req, res) => {
    try {
        const result = await BlogPost.find();
        res.status(200).json({message: "retrieve posts successfully", result})
    } catch (error) {
        return res.status(500).json({   
            message: "Internal Server Error",
            error
        })
    }
}

module.exports = {
    createPost,
    getAllPost
}