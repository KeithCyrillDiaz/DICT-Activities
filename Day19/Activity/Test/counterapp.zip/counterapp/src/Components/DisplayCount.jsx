
const DisplayCount = ({count}) => {
  return (
    <div className="display">
      Count: {count}
    </div>
  )
}

export default DisplayCount
