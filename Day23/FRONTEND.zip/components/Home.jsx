import React from 'react'

const Home = () => {
    return (
        <div className="container">
            Welcome to Hotel Reservation
        </div>
    )
}

export default Home